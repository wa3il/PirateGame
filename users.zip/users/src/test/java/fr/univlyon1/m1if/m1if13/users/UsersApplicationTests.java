package fr.univlyon1.m1if.m1if13.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
